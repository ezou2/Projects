Members: Liam Baca (wbaca1) and Emily Zou (ezou2)
For this assignment, we were able to set up a repository for github. However, there were many merge conflicts.
Liam worked on operators +, -, compare, and to_dec, while Emily worked on operators <<, *, and /. Unfortunately,
there were issues with << and / that Emily took a very long time to debug while Liam made some unit tests. In the
end, Emily couldn't find the issue, so Liam worked on fixing the bugs while Emily continued on making unit tests.
We were unable to pass a few tests for / and to_dec, our theory is that because / doesn't work perfectly, then
some part of to_dec also doesn't work since to_dec relies on /.